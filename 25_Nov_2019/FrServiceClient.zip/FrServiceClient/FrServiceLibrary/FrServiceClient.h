#ifndef MOBIFACE_CLIENT
#define MOBIFACE_CLIENT

typedef unsigned long binder_size_t;
#include <binder/IInterface.h>
#include <binder/Parcel.h>
#include <binder/IBinder.h>
#include <binder/Binder.h>
#include <binder/ProcessState.h>
#include <binder/IPCThreadState.h>
#include <binder/IServiceManager.h>
#include <stdio.h>
#include "mobiFace.h"

using namespace android;
namespace android
{
  class IMobiFaceService : public IInterface  {
  public:
    DECLARE_META_INTERFACE(MobiFaceService);
    virtual void workflow() = 0;
  };

  class BpMobiFaceService: public BpInterface<IMobiFaceService> {
  public:
    BpMobiFaceService(const sp<IBinder>& impl);
    void workflow();
  };

}

void rt_log(rt_loglevel i__level, const char* i__message, ...);
e__MOBIFACE_STATUS mobiFace_init(sp < IMobiFaceService > &mobiFaceService);
e__MOBIFACE_STATUS mobiFace_term(sp < IMobiFaceService > &mobiFaceService);
e__MOBIFACE_STATUS mobiFace_start(sp < IMobiFaceService > &mobiFaceService, const e__MOBIFACE_LIVENESS_LEVEL &level);
e__MOBIFACE_STATUS mobiFace_cancel(sp < IMobiFaceService > &mobiFaceService);
e__MOBIFACE_STATUS mobiFace_getDeviceId(sp < IMobiFaceService > &mobiFaceService, unsigned char *deviceId);
e__MOBIFACE_STATUS mobiFace_getVersion(sp < IMobiFaceService > &mobiFaceService, unsigned int &version);
e__MOBIFACE_STATUS mobiFace_pushFrameParams(sp < IMobiFaceService > &mobiFaceService, rt_colorspace colorspace, unsigned int &width, unsigned int &height, unsigned int &stride, unsigned int &orientation);
e__MOBIFACE_STATUS mobiFace_getState(sp < IMobiFaceService > &mobiFaceService, e__MOBIFACE_STATE &state);
e__MOBIFACE_STATUS mobiFace_getChallenge(sp < IMobiFaceService > &mobiFaceService, e__MOBIFACE_CHALLENGE &clg);
e__MOBIFACE_STATUS mobiFace_getPositionInfo(sp < IMobiFaceService > &mobiFaceService, e__MOBIFACE_POSITION_INFO &inf);
e__MOBIFACE_STATUS mobiFace_pushFrame(sp < IMobiFaceService > &mobiFaceService, unsigned char *frame, unsigned int len);
e__MOBIFACE_STATUS mobiFace_pushRef(sp < IMobiFaceService > &mobiFaceService, unsigned char *frame, unsigned int len);
e__MOBIFACE_STATUS mobiFace_getRef(sp < IMobiFaceService > &mobiFaceService, unsigned char *&frame, unsigned int &len);
e__MOBIFACE_STATUS mobiFace_getChallengeResponse(sp < IMobiFaceService > &mobiFaceService, e__MOBIFACE_CHALLENGERESPONSE &resp);
e__MOBIFACE_STATUS mobiFace_getChallengeDiag(sp < IMobiFaceService > &mobiFaceService, e__MOBIFACE_CHALLENGE_DIAG &diag);
e__MOBIFACE_STATUS mobiFace_getMatchingScore(sp < IMobiFaceService > &mobiFaceService, int &matchingScore);
e__MOBIFACE_STATUS mobiFace_getChallenge2DInfo(sp < IMobiFaceService > &mobiFaceService, MOBIFACE_CHALLENGE_2D_INFO &challengeInfo);
const char *MOBIFACE_CHALLENGE_To_String(e__MOBIFACE_CHALLENGE chlg);
const char *MOBIFACE_POSITION_INFO_To_String(e__MOBIFACE_POSITION_INFO inf);
const char *MOBIFACE_CHALLENGERESPONSE_To_String(e__MOBIFACE_CHALLENGERESPONSE resp);
const char *MOBIFACE_CHALLENGE_DIAG_To_String(e__MOBIFACE_CHALLENGE_DIAG diag);

#endif