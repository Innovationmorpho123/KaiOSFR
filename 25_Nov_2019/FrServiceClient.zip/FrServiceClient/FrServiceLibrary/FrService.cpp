#include "FrService.h"
#include "FrServiceClient.h"
#include <getopt.h>
#include <stdlib.h>

using namespace android;

class IdemiaFrServiceImpl : public FrServiceImpl
{
public:
    ~IdemiaFrServiceImpl();
    FrStatus Init(size_t aSize, uint8_t *aLicense);
    FrStatus StartFaceAnalysis(const FaceThreshold aThreshold, const std::vector<ImageContent> *aRefImage);
    FrStatus StopFaceAnalysis();
    FrStatus PushFrame(const ImageContent &aImageContent, AnalysisResults &aResult);
    FrStatus Deinit();

private:
    sp<IMobiFaceService> service;
    bool expectMatchScore;
};

IdemiaFrServiceImpl::~IdemiaFrServiceImpl()
{
}

FrStatus IdemiaFrServiceImpl::Init(size_t aSize, uint8_t *aLicense)
{

    sp<IServiceManager> sm = defaultServiceManager();
    sp<IBinder> binder = sm->getService(String16("com.idemia.mobiface.service"));
    if (binder == NULL)
    {
        rt_log(RT_LOGLEVEL_ERROR, "MobiFaceClient service binding failed");
        return STATUS_ERROR;
    }
    service = interface_cast<IMobiFaceService>(binder);
    int ret = mobiFace_init(service);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_ERROR, "mobiFace_init: %d", ret);
        return STATUS_ERROR;
    }

    unsigned int version;
    if ((ret = mobiFace_getVersion(service, version)) != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_INFO, "mobiFace_getVersion failed : %d", ret);
    }
    else
    {
        rt_log(RT_LOGLEVEL_INFO, "version:%08x", version);
    }

    // if (aSize > 0)
    // {
    //     FILE *fd = fopen("/data/test/license.dat", "wb");
    //     if (fd)
    //     {
    //         fwrite(aLicense, 1, aSize, fd);
    //         fclose(fd);
    //     }
    // }

    return STATUS_OK;
}
FrStatus IdemiaFrServiceImpl::StartFaceAnalysis(const FaceThreshold aThreshold, const std::vector<ImageContent> *aRefImage)
{
    e__MOBIFACE_LIVENESS_LEVEL lvl = MOBIFACE_LIVENESS_MEDIUM;
    if (aThreshold == THRESHOLD_LOW)
    {
        lvl = MOBIFACE_LIVENESS_NONE;
    }
    else if (aThreshold == THRESHOLD_HIGH)
    {
        lvl = MOBIFACE_LIVENESS_HIGH;
    }

    e__MOBIFACE_STATUS ret = mobiFace_start(service, lvl);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_ERROR, "mobiFace_start: %d", ret);
        return STATUS_ERROR;
    }

    if (aRefImage->size() > 0)
    {
#if DEBUG
        // rt_log(RT_LOGLEVEL_DEBUG, "IdemiaFrServiceImpl::StartFaceAnalysis: Size of Vector: %d", aRefImage->size());
        // rt_log(RT_LOGLEVEL_DEBUG, "IdemiaFrServiceImpl::StartFaceAnalysis: Size of Image Data: %d", aRefImage->at(0).GetSize());
#endif
        expectMatchScore = true;
        //unsigned char *frame = (unsigned char *)&(*aRefImage)[0];
        uint8_t *frame = aRefImage->at(0).GetData().get();
#if DEBUG
        // FILE *fd = fopen("/data/test/FromAppSide.bmp", "wb");
        // if (fd)
        // {
        //     fwrite(frame, 1, aRefImage->at(0).GetSize(), fd);
        //     fclose(fd);
        // }
        /*****************************************/
        rt_log(RT_LOGLEVEL_DEBUG, "IdemiaFrServiceImpl::StartFaceAnalysis: %d", aRefImage->at(0).GetSize());
/*****************************************/
#endif
        ret = mobiFace_pushRef(service, frame, aRefImage->at(0).GetSize());
        if (ret != MOBIFACE_STATUS_OK)
        {
            rt_log(RT_LOGLEVEL_ERROR, "mobiFace_pushRef: %d", ret);
            return STATUS_ERROR;
        }
    }
    else
    {
        expectMatchScore = false;
    }
    return STATUS_OK;
}
FrStatus IdemiaFrServiceImpl::StopFaceAnalysis()
{
    int ret = mobiFace_cancel(service);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_term: %d", ret);
        return STATUS_ERROR;
    }
    return STATUS_OK;
}

rt_colorspace ColorSpaceConvert(ImageType type)
{
    switch (type)
    {
    case TYPE_RGB:
        return RT_COLORSPACE_RGB24;
    case TYPE_BGR:
        return RT_COLORSPACE_BGR24;
    case TYPE_RGBA:
        return RT_COLORSPACE_RGBA32;
    case TYPE_NV12:
        return RT_COLORSPACE_NV12;
    case TYPE_NV21:
        return RT_COLORSPACE_NV21;
    default:
        return RT_COLORSPACE_INVALID;
    }
}

FrStatus IdemiaFrServiceImpl::PushFrame(const ImageContent &aImageContent, AnalysisResults &aResult)
{
#if DEBUG
    switch (aImageContent.GetType())
    {
    case ImageType::TYPE_RGBA:
        __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", "TYPE_RGBA");
        break;
    case ImageType::TYPE_BGR:
        __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", "TYPE_BGR");
        break;
    case ImageType::TYPE_NV12:
        __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", "TYPE_NV12");
        break;
    case ImageType::TYPE_NV21:
        __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", "TYPE_NV21");
        break;
    case ImageType::TYPE_RGB:
        __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", "TYPE_RGB");
        break;
    }

    uint32_t size = aImageContent.GetSize();

    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Size", "%x", size);
    //std::shared_ptr<uint8_t> data = aImageContent.GetData();

    //__android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Type", "%s", data.get());
#endif

    e__MOBIFACE_STATE mobiFaceState = MOBIFACE_UNKOWN_STATE;
    if ((mobiFace_getState(service, mobiFaceState) != MOBIFACE_STATUS_OK) || (mobiFaceState != MOBIFACE_CAPTURE_PENDING))
    {
        rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_getState no capture pending");
        return STATUS_ERROR;
    }

    rt_colorspace clrSpace = ColorSpaceConvert(aImageContent.GetType());
    unsigned int width, height, stride, orientation;

    width = aImageContent.GetWidth();
    height = aImageContent.GetHeight();
    orientation = aImageContent.GetOrientation();

#if DEBUG

    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Width", "%d", width);

    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Height", "%d", height);

    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Orientation", "%d", orientation);
#endif

    stride = aImageContent.GetSize() / aImageContent.GetWidth();
    if (clrSpace == RT_COLORSPACE_NV12)
    {
        stride = width;
    }

    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Orientation", "%d", orientation);

    int ret = mobiFace_pushFrameParams(service, clrSpace, width, height, stride, orientation);
    __android_log_print(ANDROID_LOG_DEBUG, "As FrServiceClient Orientation", "%d", orientation);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_pushFrameParams: %d", ret);
        return STATUS_ERROR;
    }

    unsigned char *frame = (uint8_t *)aImageContent.GetData().get();
    //unsigned char *frame = NULL;

    unsigned int len = aImageContent.GetSize();
    rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_pushFrame frame %p %d", frame, len);
    ret = mobiFace_pushFrame(service, frame, len);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_pushFrame: %d", ret);
        return STATUS_ERROR;
    }

    //getposition Info (used to notify user)
    e__MOBIFACE_POSITION_INFO positionInfo;
    if ((ret = mobiFace_getPositionInfo(service, positionInfo)) == MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "positionInfo %s\n", MOBIFACE_POSITION_INFO_To_String(positionInfo));
        aResult.SetFaceAnalysisInfo((FaceAnalysisInfo)positionInfo);
    }

    // on slam mode get challenge info // liveness medium mode
    e__MOBIFACE_CHALLENGE positionChallenge;
    if ((ret = mobiFace_getChallenge(service, positionChallenge)) == MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "positionChallenge %s\n", MOBIFACE_CHALLENGE_To_String(positionChallenge));
        std::vector<uint8_t> mPayload;
        mPayload.resize(sizeof(e__MOBIFACE_CHALLENGE));
        memcpy(&mPayload[0], &positionChallenge, sizeof(e__MOBIFACE_CHALLENGE));
        rt_log(RT_LOGLEVEL_DEBUG, "e__MOBIFACE_CHALLENGE Position Challenge size %d\n", mPayload.size());

        for (int i = 0; i < mPayload.size(); i++)
            rt_log(RT_LOGLEVEL_DEBUG, "e__MOBIFACE_CHALLENGE Position Challenge Data %d\n", mPayload[i]);

        aResult.SetAdditionalInfo(mPayload);
    }

    //getChallenge info to display target and circles on screen // liveness high mode
    MOBIFACE_CHALLENGE_2D_INFO challengeInfo;
    if ((ret = mobiFace_getChallenge2DInfo(service, challengeInfo)) == MOBIFACE_STATUS_OK)
    {

#if DEBUG
        // /****************************DEFAULT FOR TEST*********************/
        // challengeInfo.availableCurrentPosition = true;
        // challengeInfo.current_x = 120;
        // challengeInfo.current_y = 130;
        // challengeInfo.stability = 4;
        // challengeInfo.availableTargetPosition = true;
        // challengeInfo.currentTarget = 1;
        // challengeInfo.numTargets = 3;
        // challengeInfo.targets[0] = {200, 200, 4};
        // challengeInfo.targets[1] = {50, 60, 4};
        // challengeInfo.targets[2] = {50, 210, 4};
        // /******************************************************************/

        /***************** Convert to byte Array JSON encoding **************/
#endif

        challengeInfo.current_x = int(challengeInfo.current_x * 0.6);
        challengeInfo.current_y = int(challengeInfo.current_y * 0.6);

        challengeInfo.targets[0].target_x = int(challengeInfo.targets[0].target_x * 0.6);
        challengeInfo.targets[0].target_y = int(challengeInfo.targets[0].target_y * 0.6);
        challengeInfo.targets[0].target_radius = int(challengeInfo.targets[0].target_radius * 0.6);

        challengeInfo.targets[1].target_x = int(challengeInfo.targets[1].target_x * 0.6);
        challengeInfo.targets[1].target_y = int(challengeInfo.targets[1].target_y * 0.6);
        challengeInfo.targets[1].target_radius = int(challengeInfo.targets[1].target_radius * 0.6);

        challengeInfo.targets[2].target_x = int(challengeInfo.targets[2].target_x * 0.6);
        challengeInfo.targets[2].target_y = int(challengeInfo.targets[2].target_y * 0.6);
        challengeInfo.targets[2].target_radius = int(challengeInfo.targets[2].target_radius * 0.6);

        std::string lspayload;

        lspayload += "{\"challengeInfo\":{\"availableCurrentPosition\":";
        lspayload += challengeInfo.availableCurrentPosition ? "true" : "false";
        lspayload += ",\"current_x\":";
        lspayload += std::to_string(challengeInfo.current_x);
        lspayload += ",\"current_y\":";
        lspayload += std::to_string(challengeInfo.current_y);
        lspayload += ",\"stability\":";
        lspayload += std::to_string(challengeInfo.stability);
        lspayload += ",\"availableTargetPosition\":";
        lspayload += challengeInfo.availableTargetPosition ? "true" : "false";
        lspayload += ",\"currentTarget\":";
        lspayload += std::to_string(challengeInfo.currentTarget);
        lspayload += ",\"numTargets\":";
        lspayload += std::to_string(challengeInfo.numTargets);
        lspayload += ",\"targets\":[{\"target_x\":";
        lspayload += std::to_string(challengeInfo.targets[0].target_x);
        lspayload += ",\"target_y\":";
        lspayload += std::to_string(challengeInfo.targets[0].target_y);
        lspayload += ",\"target_radius\":";
        lspayload += std::to_string(challengeInfo.targets[0].target_radius);
        lspayload += "},{\"target_x\":";
        lspayload += std::to_string(challengeInfo.targets[1].target_x);
        lspayload += ",\"target_y\":";
        lspayload += std::to_string(challengeInfo.targets[1].target_y);
        lspayload += ",\"target_radius\":";
        lspayload += std::to_string(challengeInfo.targets[1].target_radius);
        lspayload += "},{\"target_x\":";
        lspayload += std::to_string(challengeInfo.targets[2].target_x);
        lspayload += ",\"target_y\":";
        lspayload += std::to_string(challengeInfo.targets[2].target_y);
        lspayload += ",\"target_radius\":";
        lspayload += std::to_string(challengeInfo.targets[2].target_radius);
        lspayload += "}]}}";

        /********************************************************************/

        rt_log(RT_LOGLEVEL_DEBUG, "challenge2DInfo %d %d - %d %d - %d %d", challengeInfo.current_x, challengeInfo.current_y, challengeInfo.targets[0].target_x, challengeInfo.targets[0].target_y,
               challengeInfo.targets[1].target_x, challengeInfo.targets[1].target_y);

        // std::vector<uint8_t> mPayload;
        // mPayload.resize(sizeof(MOBIFACE_CHALLENGE_2D_INFO));
        // memcpy(&mPayload[0], &challengeInfo, sizeof(MOBIFACE_CHALLENGE_2D_INFO));

        std::vector<uint8_t> mPayload(lspayload.begin(), lspayload.end());

#if DEBUG
        // for (int i = 0; i < mPayload.size(); i++)
        //     rt_log(RT_LOGLEVEL_DEBUG, "challenge2DInfo data %u", mPayload[i]);
#endif
        // rt_log(RT_LOGLEVEL_DEBUG, "e__MOBIFACE_CHALLENGE Position Challenge size %d\n", mPayload.size());
        // std::string s;
        // for (int i = 0; i < mPayload.size(); i++)
        // {
        //     s += std::to_string(mPayload[i]);
        //     //rt_log(RT_LOGLEVEL_DEBUG, "e__MOBIFACE_CHALLENGE Position Challenge Data %d\n", mPayload[i]);
        // }
        // char char_array[s.length()];
        // strcpy(char_array, s.c_str());
        // rt_log(RT_LOGLEVEL_DEBUG, "e__MOBIFACE_CHALLENGE Position Challenge Data %s\n", char_array);

        aResult.SetAdditionalInfo(mPayload);
    }

    if ((mobiFace_getState(service, mobiFaceState) == MOBIFACE_STATUS_OK) && (mobiFaceState != MOBIFACE_CAPTURE_PENDING))
    {

        bool chlgSuccess = true;
        //indicate if liveness check did succeed
        e__MOBIFACE_CHALLENGERESPONSE chlgResp;
        if ((ret = mobiFace_getChallengeResponse(service, chlgResp)) == MOBIFACE_STATUS_OK)
        {
            if (chlgResp != MOBIFACE_CHALLENGERESPONSE_SUCCESS)
            {
                rt_log(RT_LOGLEVEL_INFO, "challenge failed");
                chlgSuccess = false;
            }
            rt_log(RT_LOGLEVEL_DEBUG, "challengeResponse %s", MOBIFACE_CHALLENGERESPONSE_To_String(chlgResp));
        }
        else
        {
            rt_log(RT_LOGLEVEL_DEBUG, "no challengeResponse");
        }

        if (chlgSuccess && expectMatchScore)
        {
            int matchingScore;
            if ((ret = mobiFace_getMatchingScore(service, matchingScore)) == MOBIFACE_STATUS_OK)
            {
                rt_log(RT_LOGLEVEL_DEBUG, "setting matchingScore");
                aResult.SetMatchScore(matchingScore);

                /* Get Best Image */

                unsigned char *refFrame;
                uint8_t *bstImg = NULL;
                unsigned int refFrameLen;
                if ((ret = mobiFace_getRef(service, refFrame, refFrameLen)) == MOBIFACE_STATUS_OK)
                {

                    if (refFrameLen > 0)
                    {
                        bstImg = (uint8_t *)malloc(refFrameLen * sizeof(uint8_t));

                        memcpy(bstImg, refFrame, refFrameLen);
                        rt_log(RT_LOGLEVEL_DEBUG, "image %p", bstImg);

                        std::shared_ptr<uint8_t> bestImage(bstImg);
                        //ImageContent *image = new ImageContent(aImageContent.GetWidth(), aImageContent.GetHeight(), aImageContent.GetType(), (size_t)refFrameLen, bestImage);
                        //rt_log(RT_LOGLEVEL_DEBUG, "imageContent %p", image);
                        std::shared_ptr<ImageContent> bst{new ImageContent(aImageContent.GetWidth(), aImageContent.GetHeight(), aImageContent.GetType(), (size_t)refFrameLen, bestImage, aImageContent.GetOrientation())};
#if DEBUG
                        rt_log(RT_LOGLEVEL_DEBUG, "Before setting Image");

                        // FILE *fd = fopen("/data/test/bestImg-fr-aftermatchingscore.bmp", "wb");
                        // if (fd)
                        // {
                        //     fwrite(bestImage.get(), 1, refFrameLen, fd);
                        //     fclose(fd);
                        // }
#endif
                        aResult.SetBestImage(bst);

                        rt_log(RT_LOGLEVEL_DEBUG, "setting bestImage");
                    }
                    else
                    {
                        rt_log(RT_LOGLEVEL_DEBUG, "bstImg not available");
                    }
                }
            }
            else
            {
                rt_log(RT_LOGLEVEL_DEBUG, "setting matchingScore not available");
            }
        }
        else if (chlgSuccess)
        {
            //std::vector<uint8_t> bstImg;
            unsigned char *refFrame;
            uint8_t *bstImg = NULL;
            unsigned int refFrameLen;
            if ((ret = mobiFace_getRef(service, refFrame, refFrameLen)) == MOBIFACE_STATUS_OK)
            {
                //bstImg.resize(refFrameLen);
                //memcpy(&bstImg[0],refFrame,refFrameLen);
                //free(refFrame);
                //refFrame=NULL;
                //aResult.SetBestImage(bstImg);

                if (refFrameLen > 0)
                {
                    bstImg = (uint8_t *)malloc(refFrameLen * sizeof(uint8_t));

                    memcpy(bstImg, refFrame, refFrameLen);
                    rt_log(RT_LOGLEVEL_DEBUG, "image %p", bstImg);

                    std::shared_ptr<uint8_t> bestImage(bstImg);
                    //ImageContent *image = new ImageContent(aImageContent.GetWidth(), aImageContent.GetHeight(), aImageContent.GetType(), (size_t)refFrameLen, bestImage);
                    //rt_log(RT_LOGLEVEL_DEBUG, "imageContent %p", image);
                    std::shared_ptr<ImageContent> bst{new ImageContent(aImageContent.GetWidth(), aImageContent.GetHeight(), aImageContent.GetType(), (size_t)refFrameLen, bestImage, aImageContent.GetOrientation())};
#if DEBUG
                    rt_log(RT_LOGLEVEL_DEBUG, "Before setting Image");

                    // FILE *fd = fopen("/data/test/bestImg-fr1.bmp", "wb");
                    // if (fd)
                    // {
                    //     fwrite(bestImage.get(), 1, refFrameLen, fd);
                    //     fclose(fd);
                    // }

#endif
                    aResult.SetBestImage(bst);

                    rt_log(RT_LOGLEVEL_DEBUG, "setting bestImage");
                }
                else
                {
                    rt_log(RT_LOGLEVEL_DEBUG, "bstImg not available");
                }
            }
            else
            {
                rt_log(RT_LOGLEVEL_DEBUG, "setting bstImg not available");
            }
        }
    }

    return STATUS_OK;
}
FrStatus IdemiaFrServiceImpl::Deinit()
{
    int ret = mobiFace_term(service);
    if (ret != MOBIFACE_STATUS_OK)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "mobiFace_term: %d", ret);
        return STATUS_ERROR;
    }
    return STATUS_OK;
}

extern "C"
{
    FrServiceImpl *CreateFrService()
    {
        rt_log(RT_LOGLEVEL_DEBUG, "Creating FrService");
        return new IdemiaFrServiceImpl();
    }
}