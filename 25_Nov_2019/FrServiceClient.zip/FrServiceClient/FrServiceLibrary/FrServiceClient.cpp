#include "FrServiceClient.h"
#include "mobiFace.h"

using namespace android;

namespace android
{
IMPLEMENT_META_INTERFACE(MobiFaceService, "android.fr.IMobiFaceService");

typedef struct
{
    Parcel data, reply;
    int cmd;
} Transaction;

Transaction clt;

// Client
BpMobiFaceService::BpMobiFaceService(const sp<IBinder> &impl) : BpInterface<IMobiFaceService>(impl)
{
}

void BpMobiFaceService::workflow()
{
    clt.data.writeInterfaceToken(IMobiFaceService::getInterfaceDescriptor());
    remote()->transact(clt.cmd, clt.data, &clt.reply);
}
} // namespace android

void Init()
{
}

void printHex(unsigned char *data, size_t len)
{
    int i = 0;
    for (i = 0; i < len; i++)
    {
        printf("%02x ", (unsigned char)data[i]);
    }
    printf("\n");
}

void hexToBin(const char *in, unsigned char *out)
{
    const char *tmp = in;
    int cnt = 0;
    unsigned char val = 0;
    unsigned char *tmpOut = out;
    while (*tmp != '\0')
    {
        if (cnt % 2)
        {
            val = val << 4;
        }
        if (*tmp >= 'a')
        {
            val |= (*tmp) - 'a' + 10;
        }
        else if (*tmp >= 'A')
        {
            val |= (*tmp) - 'A' + 10;
        }
        else
        {
            val |= (*tmp) - '0';
        }
        if (cnt % 2)
        {
            *tmpOut = val;
            tmpOut++;
            val = 0;
        }
        cnt++;
        tmp++;
    }
}

int g_livenessLevel = MOBIFACE_LIVENESS_MEDIUM;

void rt_log(rt_loglevel i__level, const char *i__message, ...)
{
    char msg[512] = {0};
    const char *level;
    const char *sessionId = "";

    android_LogPriority priority;
    switch (i__level)
    {
    case RT_LOGLEVEL_DEBUG:
        priority = ANDROID_LOG_DEBUG;
        break;
    case RT_LOGLEVEL_INFO:
        priority = ANDROID_LOG_INFO;
        break;
    case RT_LOGLEVEL_WARNING:
        priority = ANDROID_LOG_WARN;
        break;
    case RT_LOGLEVEL_ERROR:
    default:
        priority = ANDROID_LOG_ERROR;
        break;
    }

    switch (i__level)
    {

    case RT_LOGLEVEL_DEBUG: ///< Debug message
        level = "DEBUG";
        break;
    case RT_LOGLEVEL_INFO: ///< Informative message
        level = "INFO";
        break;
    case RT_LOGLEVEL_WARNING: ///< Warning message
        level = "WARN";
        break;
    case RT_LOGLEVEL_ERROR:
    default:
        level = "ERROR";
        break;
    }
    va_list pArg;
    va_start(pArg, i__message);
    int msgLen = snprintf(msg, sizeof(msg), "%s %s - ", sessionId, level);
    msgLen = vsnprintf(msg + msgLen, sizeof(msg) - msgLen, i__message, pArg);
    va_end(pArg);
    msg[sizeof(msg) - 1] = '\0';

    __android_log_print(priority, "FrServiceClient", "%s", msg);
    //fprintf(stderr, "%s\n", msg);
}

e__MOBIFACE_STATUS mobiFace_init(sp<IMobiFaceService> &mobiFaceService)
{
    printf("mobiFace_init\n");
    int32_t ret = -1;
    clt.cmd = MOBIFACE_INIT;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32((int32_t *)&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_term(sp<IMobiFaceService> &mobiFaceService)
{
    printf("mobiFace_term\n");
    int32_t ret = -1;
    clt.cmd = MOBIFACE_TERM;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_start(sp<IMobiFaceService> &mobiFaceService, const e__MOBIFACE_LIVENESS_LEVEL &level)
{
    printf("mobiFace_start\n");
    int32_t ret = -1;
    clt.cmd = MOBIFACE_START;
    clt.data.freeData();
    clt.reply.freeData();
    clt.data.writeInt32(level);
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_cancel(sp<IMobiFaceService> &mobiFaceService)
{
    printf("mobiFace_cancel\n");
    int32_t ret = -1;
    clt.cmd = MOBIFACE_CANCEL;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_getDeviceId(sp<IMobiFaceService> &mobiFaceService, unsigned char *deviceId)
{
    printf("mobiFace_getDeviceId\n");
    String8 deviceIdStr;
    clt.cmd = MOBIFACE_GET_DEVICE_ID;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    deviceIdStr = clt.reply.readString8();
    if (deviceIdStr.length() != 64)
    { //deviceId is 32 bytes (64 hex)
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    hexToBin((const char *)deviceIdStr.string(), deviceId);
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getVersion(sp<IMobiFaceService> &mobiFaceService, unsigned int &version)
{
    printf("mobiFace_getVersion\n");
    String8 deviceIdStr;
    clt.cmd = MOBIFACE_GET_VERSION;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32((int *)&version) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_pushFrameParams(sp<IMobiFaceService> &mobiFaceService, rt_colorspace colorspace, unsigned int &width, unsigned int &height, unsigned int &stride, unsigned int &orientation)
{
    printf("mobiFace_pushFrameParams\n");
    int32_t ret = -1;
    clt.cmd = MOBIFACE_PUSH_FRAME_PARAMS;
    clt.data.freeData();
    clt.reply.freeData();
    clt.data.writeInt32((int)colorspace);
    clt.data.writeInt32((int)width);
    clt.data.writeInt32((int)height);
    clt.data.writeInt32((int)stride);
    clt.data.writeInt32((int)orientation);
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_getState(sp<IMobiFaceService> &mobiFaceService, e__MOBIFACE_STATE &state)
{
    printf("mobiFace_getState\n");
    int32_t ret = -1;
    state = MOBIFACE_UNKOWN_STATE;
    clt.cmd = MOBIFACE_GET_STATE;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    state = (e__MOBIFACE_STATE)ret;
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getChallenge(sp<IMobiFaceService> &mobiFaceService, e__MOBIFACE_CHALLENGE &clg)
{
    printf("mobiFace_getChallenge\n");
    int32_t ret = -1;
    clg = MOBIFACE_CHALLENGE_DON_T_MOVE;
    clt.cmd = MOBIFACE_GET_CHALLENGE;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    clg = (e__MOBIFACE_CHALLENGE)ret;
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getPositionInfo(sp<IMobiFaceService> &mobiFaceService, e__MOBIFACE_POSITION_INFO &inf)
{
    printf("mobiFace_getPositionInfo\n");
    int32_t ret = -1;
    inf = MOBIFACE_POSITION_INFO_GOOD;
    clt.cmd = MOBIFACE_GET_POSITION_INFO;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    inf = (e__MOBIFACE_POSITION_INFO)ret;
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_pushFrameOrRef(sp<IMobiFaceService> &mobiFaceService, unsigned char *frame, unsigned int len, bool isFrame)
{
    int32_t ret = -1;
    clt.cmd = MOBIFACE_PUSH_REF;
    if (isFrame)
        clt.cmd = MOBIFACE_PUSH_FRAME;
    clt.data.freeData();
    clt.reply.freeData();
    rt_log(RT_LOGLEVEL_DEBUG, "IdemiaFrServiceImpl::StartFaceAnalysis: FrServiceClient %d", len);
    clt.data.writeInt32((int)len);

    Parcel::WritableBlob blob;
    ret = clt.data.writeBlob(len, false, &blob);
    if (ret != NO_ERROR)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    memcpy(blob.data(), frame, len);
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return (e__MOBIFACE_STATUS)ret;
}

e__MOBIFACE_STATUS mobiFace_pushFrame(sp<IMobiFaceService> &mobiFaceService, unsigned char *frame, unsigned int len)
{
    printf("mobiFace_pushFrame\n");
    return mobiFace_pushFrameOrRef(mobiFaceService, frame, len, true);
}

e__MOBIFACE_STATUS mobiFace_pushRef(sp<IMobiFaceService> &mobiFaceService, unsigned char *frame, unsigned int len)
{
    printf("mobiFace_pushRef\n");
    return mobiFace_pushFrameOrRef(mobiFaceService, frame, len, false);
}

e__MOBIFACE_STATUS mobiFace_getRef(sp<IMobiFaceService> &mobiFaceService, unsigned char *&frame, unsigned int &len)
{
    printf("mobiFace_getRef\n");
    clt.cmd = MOBIFACE_GET_REF;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32((int32_t *)&len) != 0)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "frame len failed to read");
        return MOBIFACE_STATUS_INTERNAL_ERROR;
    }
    if (clt.reply.readInt32((int32_t *)&len) != 0)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "frame len failed to read");
        return MOBIFACE_STATUS_INTERNAL_ERROR;
    }

    Parcel::ReadableBlob blob;
    if (clt.reply.readBlob(len, &blob) != 0)
    {
        rt_log(RT_LOGLEVEL_DEBUG, "frame failed to read data");
        return MOBIFACE_STATUS_INTERNAL_ERROR;
    }
    frame = (unsigned char *)malloc(len);
    memcpy(frame, (unsigned char *)blob.data(), len);

    rt_log(RT_LOGLEVEL_DEBUG, "frame: %p %d", frame, len);

    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getChallengeResponse(sp<IMobiFaceService> &mobiFaceService, e__MOBIFACE_CHALLENGERESPONSE &resp)
{
    printf("mobiFace_getChallengeResponse\n");
    int32_t ret = -1;
    resp = MOBIFACE_CHALLENGERESPONSE_FAILED;
    clt.cmd = MOBIFACE_GET_CHALLENGE_RESPONSE;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    resp = (e__MOBIFACE_CHALLENGERESPONSE)ret;
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getChallengeDiag(sp<IMobiFaceService> &mobiFaceService, e__MOBIFACE_CHALLENGE_DIAG &diag)
{
    printf("mobiFace_getChallengeDiag\n");
    int32_t ret = -1;
    diag = MOBIFACE_CHALLENGE_DIAG_NO_INFO;
    clt.cmd = MOBIFACE_GET_CHALLENGE_DIAG;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&ret) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    diag = (e__MOBIFACE_CHALLENGE_DIAG)ret;
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getMatchingScore(sp<IMobiFaceService> &mobiFaceService, int &matchingScore)
{
    printf("mobiFace_getMatchingScore\n");
    clt.cmd = MOBIFACE_GET_MATCHING_SCORE;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.readInt32(&matchingScore) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return MOBIFACE_STATUS_OK;
}

e__MOBIFACE_STATUS mobiFace_getChallenge2DInfo(sp<IMobiFaceService> &mobiFaceService, MOBIFACE_CHALLENGE_2D_INFO &challengeInfo)
{
    printf("mobiFace_getChallenge2DInfo\n");
    clt.cmd = MOBIFACE_GET_CHALLENGE_2D_INFO;
    clt.data.freeData();
    clt.reply.freeData();
    mobiFaceService->workflow();
    if (clt.reply.read(&challengeInfo, sizeof(MOBIFACE_CHALLENGE_2D_INFO)) != 0)
    {
        return MOBIFACE_STATUS_SERVICE_ERROR;
    }
    return MOBIFACE_STATUS_OK;
}

const char *MOBIFACE_CHALLENGE_To_String(e__MOBIFACE_CHALLENGE chlg)
{
    const char *str;
    switch (chlg)
    {
    case MOBIFACE_CHALLENGE_TURN_FACE_TO_LEFT:
        str = "MOBIFACE_CHALLENGE_TURN_FACE_TO_LEFT";
        break;
    case MOBIFACE_CHALLENGE_TURN_FACE_TO_RIGHT:
        str = "MOBIFACE_CHALLENGE_TURN_FACE_TO_RIGHT";
        break;
    case MOBIFACE_CHALLENGE_TURN_FACE_TO_LEFT_THEN_TO_THE_RIGHT:
        str = "MOBIFACE_CHALLENGE_TURN_FACE_TO_LEFT_THEN_TO_THE_RIGHT";
        break;
    case MOBIFACE_CHALLENGE_MOVE_FACE_DOWN:
        str = "MOBIFACE_CHALLENGE_MOVE_FACE_DOWN";
        break;
    case MOBIFACE_CHALLENGE_MOVE_FACE_UP:
        str = "MOBIFACE_CHALLENGE_MOVE_FACE_UP";
        break;
    case MOBIFACE_CHALLENGE_DON_T_MOVE:
        str = "MOBIFACE_CHALLENGE_DON_T_MOVE";
        break;
    case MOBIFACE_CHALLENGE_TURN_YOUR_FACE_LEFT_OR_RIGHT:
        str = "MOBIFACE_CHALLENGE_TURN_YOUR_FACE_LEFT_OR_RIGHT";
        break;
    case MOBIFACE_CHALLENGE_2D:
        str = "MOBIFACE_CHALLENGE_2D";
        break;
    default:
        str = "UNKNOWN_CHALLENGE_VALUE";
        break;
    }
    return str;
}

const char *MOBIFACE_POSITION_INFO_To_String(e__MOBIFACE_POSITION_INFO inf)
{
    const char *str;
    switch (inf)
    {
    case MOBIFACE_POSITION_INFO_GOOD:
        str = "MOBIFACE_POSITION_INFO_GOOD";
        break;
    case MOBIFACE_POSITION_INFO_MOVE_BACK_INTO_FRAME:
        str = "MOBIFACE_POSITION_INFO_MOVE_BACK_INTO_FRAME";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_MOVE_BACKWARDS:
        str = "MOBIFACE_POSITION_INFO_CENTER_MOVE_BACKWARDS";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_MOVE_FORWARDS:
        str = "MOBIFACE_POSITION_INFO_CENTER_MOVE_FORWARDS";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_TURN_RIGHT:
        str = "MOBIFACE_POSITION_INFO_CENTER_TURN_RIGHT";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_TURN_LEFT:
        str = "MOBIFACE_POSITION_INFO_CENTER_TURN_LEFT";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_ROTATE_UP:
        str = "MOBIFACE_POSITION_INFO_CENTER_ROTATE_UP";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_ROTATE_DOWN:
        str = "MOBIFACE_POSITION_INFO_CENTER_ROTATE_DOWN";
        break;
    case MOBIFACE_POSITION_INFO_MOVING_TOO_FAST:
        str = "MOBIFACE_POSITION_INFO_MOVING_TOO_FAST";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_TILT_RIGHT:
        str = "MOBIFACE_POSITION_INFO_CENTER_TILT_RIGHT";
        break;
    case MOBIFACE_POSITION_INFO_CENTER_TILT_LEFT:
        str = "MOBIFACE_POSITION_INFO_CENTER_TILT_LEFT";
        break;
    case MOBIFACE_POSITION_INFO_MOVE_DARKER_AREA:
        str = "MOBIFACE_POSITION_INFO_MOVE_DARKER_AREA";
        break;
    case MOBIFACE_POSITION_INFO_MOVE_BRIGHTER_AREA:
        str = "MOBIFACE_POSITION_INFO_MOVE_BRIGHTER_AREA";
        break;
    case MOBIFACE_POSITION_INFO_STAND_STILL:
        str = "MOBIFACE_POSITION_INFO_STAND_STILL";
        break;
    case MOBIFACE_POSITION_INFO_OPEN_EYES:
        str = "MOBIFACE_POSITION_INFO_OPEN_EYES";
        break;
    default:
        str = "MOBIFACE_POSITION_INFO_UNKNOWN";
        break;
    }
    return str;
}

const char *MOBIFACE_CHALLENGERESPONSE_To_String(e__MOBIFACE_CHALLENGERESPONSE resp)
{
    const char *str;
    switch (resp)
    {
    case MOBIFACE_CHALLENGERESPONSE_SUCCESS:
        str = "MOBIFACE_CHALLENGERESPONSE_SUCCESS";
        break;
    case MOBIFACE_CHALLENGERESPONSE_FAILED:
        str = "MOBIFACE_CHALLENGERESPONSE_FAILED";
        break;
    case MOBIFACE_CHALLENGERESPONSE_SPOOF:
        str = "MOBIFACE_CHALLENGERESPONSE_SPOOF";
        break;
    case MOBIFACE_CHALLENGERESPONSE_TIMEOUT:
        str = "MOBIFACE_CHALLENGERESPONSE_TIMEOUT";
        break;
    default:
        str = "MOBIFACE_CHALLENGERESPONSE_UNKNOWN";
        break;
    }
    return str;
}

const char *MOBIFACE_CHALLENGE_DIAG_To_String(e__MOBIFACE_CHALLENGE_DIAG diag)
{
    const char *str;
    switch (diag)
    {
    case MOBIFACE_CHALLENGE_DIAG_NO_INFO:
        str = "MOBIFACE_CHALLENGE_DIAG_NO_INFO";
        break;
    case MOBIFACE_CHALLENGE_DIAG_MOVEMENT_DURING_FLASH:
        str = "MOBIFACE_CHALLENGE_DIAG_MOVEMENT_DURING_FLASH";
        break;
    case MOBIFACE_CHALLENGE_DIAG_TOO_BRIGHT:
        str = "MOBIFACE_CHALLENGE_DIAG_TOO_BRIGHT";
        break;
    default:
        str = "MOBIFACE_CHALLENGE_DIAG_UNKOWN";
        break;
    }
    return str;
}
