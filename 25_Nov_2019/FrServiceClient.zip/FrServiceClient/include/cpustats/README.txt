This is a static library of CPU usage statistics, originally written
for audio but most are not actually specific to audio.

Requirements to be here:
 * should be related to CPU usage statistics
 * should be portable to host; avoid Android OS dependencies without a conditional
